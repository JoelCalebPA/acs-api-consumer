# Alfresco API Consumer

Esta librería para java se usa par aconsumir los servicios REST de Alfresco

## Uso

Desde Java API Test