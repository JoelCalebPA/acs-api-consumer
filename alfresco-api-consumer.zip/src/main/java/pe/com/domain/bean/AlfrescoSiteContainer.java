package pe.com.domain.bean;

public class AlfrescoSiteContainer {

    private String id;
    private String folderId;

    public AlfrescoSiteContainer() {
        super();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFolderId() {
        return folderId;
    }

    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }

}
