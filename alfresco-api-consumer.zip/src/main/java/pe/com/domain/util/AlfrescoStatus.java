package pe.com.domain.util;

public class AlfrescoStatus {
	
	public static final int ID_NOT_AVAILABLE = 409;
	public static final int NOT_FOUND = 404;
	
}
